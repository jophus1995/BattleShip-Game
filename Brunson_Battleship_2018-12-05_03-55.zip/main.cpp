#include "gameClass.h"

#include<iostream>
#include<cstdlib>
#include<iomanip>
using namespace std;

int main() {
srand(10);
gameClass game;
char ans;
int numShips;
int targetsOpen;
int totalBombs = 0;

cout << "Do you want to cheat?Y/N " << endl;
cin >> ans;
if( ans == 'Y'){

game.rules();

cout << "How many ships would you like to play with? ";
cin >> numShips;
 while(numShips > 10){
    if(numShips > 10){
        cout << "That number will not work for this board. Try again:";
        cin >> numShips;
    }
    }

for(int i = 0; i < numShips;i++){
game.placeShip(targetsOpen);
}
    game.dispBoardCheat();
    cout << endl;
    game.dispBoard();
    cout << endl;
    
    while(targetsOpen != 0 && totalBombs == 0){
    game.dropBomb(targetsOpen);
    game.dispBoardCheat();
    cout << endl;
    game.dispBoard();
    cout << endl;
    }
   
}else if(ans == 'N'){
    game.rules();
    cout << endl;
    cout << "How many ships would you like to play with? ";
    cin >> numShips;
    while(numShips > 10){
    if(numShips > 10){
        cout << "That number will not work for this board. Try again:";
        cin >> numShips;
    }
    }
    for(int i = 0; i < numShips;i++){
        game.placeShip(targetsOpen);
    }

    game.dispBoard();
    cout << endl;
}
while(targetsOpen != 0 && totalBombs == 0){
    int totalBombs = SIZE * 2 + targetsOpen;
    game.dropBomb(targetsOpen);
    game.dispBoard();
    cout << endl;
    
}
if(totalBombs = 0){
    cout <<"You LOSE.....loser!" << endl;
}
if(targetsOpen == 0){
    cout << "End Game" << endl;
    game.dispBoard();
    cout << "You Won!!  To bad, you blew all the ships up." << endl;
}




















}
