#ifndef LISTCPP
#define LISTCPP
#include "list.h"

using namespace std;
//Basic constructor, sets size = 0
template<typename LISTTYPE>
List <LISTTYPE>::List(){
    this -> size = 0;
}
// Inserts an item into the list
template<typename LISTTYPE>
void List <LISTTYPE>:: insert(const LISTTYPE item) {
    if (size < MAX_SIZE && size >= 0) {
        items[size] = item;
        size++;
    }
  
}
// Outputs all elements in the list
template<typename LISTTYPE>
 void List <LISTTYPE>:: print() const{
    for (int i = 0; i < size;i++){
        cout << items[i];
    }
}
// Returns true if the list is empty
template<typename LISTTYPE>
 bool List <LISTTYPE>:: isEmpty() const{
     if(size == 0){
        return true;
    }else{
        return false;
    }
}
// Returns the size of the list
template<typename LISTTYPE>
 int List <LISTTYPE>:: getSize() const{
    return size;
}
// Returns true if item is found, passes back what is in the index.
template<typename LISTTYPE>
 bool List <LISTTYPE>:: retrieve(int index,LISTTYPE &value) const{
        if(index >= 0 && index < 10){
            value = items[index];
            return true;
        }else{
            return false;
        }
    }

// Removes an item from the list given a position
template<typename LISTTYPE>
LISTTYPE List <LISTTYPE>:: remove(int index){
    for(int i = 0; i < size;i++){
        if(i == index){
        index = items[i];
        for(int j = i;j<size - 1;j++){
            items[j] = items[j+1];
        }
    size --;
    break;
    }
}
return index;
}
    


// Sorts the list
template<typename LISTTYPE>
void List<LISTTYPE>:: sort() {
    cout << "Sorting .........." << endl;
    int i = 0;
    int j = 0;
    LISTTYPE temp[MAX_SIZE];
    for(int i = 0; i < size - 1;i++)
        for (int j = 0;j < size - 1 - i;j++)
            if(items[j] > items[j+1])
                temp[j] = items[j];
                items[i] = items[j+1];
                items[j+1] = temp[j];
}
// Insets an item into the list at a position
template<typename LISTTYPE>
void List<LISTTYPE>:: replace(const LISTTYPE newItem,int index) {
            items[index] = newItem;
}


#endif



