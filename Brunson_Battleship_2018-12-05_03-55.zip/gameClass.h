//
//  board.hpp
//  Battleship
//
//  Created by Jennifer Polack on 9/25/18.
//  Copyright © 2018 Jennifer Polack. All rights reserved.
//

#ifndef boardH
#define boardH
#include "list.h"
const int SIZE = 10; //Board size in the x and y directions (between 10 and 20)
class gameClass{
public:
    gameClass() ;
    const char BLANK = ' '; //Declare what a blank is
    const char SHIP = 'S';  //for final output & stored array
    const char MISS = 'o';  //Miss
    const char HIT = 'X';   //Hit
    const char NOBOMB = '.'; //Not bombed for user display

    void rules();
    void fillBoard(char boardFill, char userFill);
    void placeShip(int& targetsOpen);
    void boardShipRewrite();
    void dropBomb(int& targetsOpen);
    void dispBoardCheat();
    void dispBoard();
private:
        List<char> board[SIZE];         //init main play board
        List<char> userView[SIZE];      //User view, only shows bombs dropped
};

#endif /* board_hpp */
