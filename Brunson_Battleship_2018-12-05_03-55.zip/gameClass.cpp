//Joshua Brunson
#ifndef GAMECLASSCPP
#define GAMECLASSCPP
#include "gameClass.h"
#include <iomanip>
#include<cstdlib>

using namespace std;

//Constructor sets up boards
gameClass::gameClass() {
    char boardFill = BLANK;
    char userFill = NOBOMB;
   fillBoard(boardFill,userFill);
}
//Sets userView to NOBOMB and board to BLANK

void gameClass:: fillBoard(char boardFill, char userFill) { 
    for(int i = 0; i < SIZE;i++){
        for(int j = 0; j < SIZE;j++) {
            userView[j].insert(userFill);
            board[j].insert(boardFill);
        }
    }
}
//Places ships on the board
void gameClass:: placeShip(int& targetsOpen){
bool temp = true;
bool temp1 = true;
int xFact;
int yFact;
while(temp){   
   int row = rand()%SIZE;
   int col = rand()%SIZE;
    while(temp1){
        do {
            xFact = rand()%3 - 1;
            yFact = rand()%3 -1;
        }while(xFact == 0 && yFact == 0);
            if(row + (xFact *3) < 10 && row + (xFact *3) > 0){
                if(col + (yFact * 3)<10 && col + (yFact * 3) > 0){
                    board[row].replace(SHIP,col);
                    board[row + (xFact * 1)].replace(SHIP,(col + (yFact * 1)));
                    board[row + (xFact * 2)].replace(SHIP,(col + (yFact * 2)));
                    board[row + (xFact * 3)].replace(SHIP,(col + (yFact * 3)));
                    targetsOpen = targetsOpen + 4;
                    temp1=false;
                    temp = false;
            }
                }
    }
}
}
void gameClass:: dropBomb(int& targetsOpen) {
    int col,row,numShips = 0;
    int totalBombs = SIZE * 2 + targetsOpen;
    char temp;
    cout << "You have " << totalBombs << "bombs.Key: \"X\"=Hit, \"o\"=Miss, \".\"=Not bombed" << endl;
    cout << "Please endter coord pair to drop bomb (Col,Row): ";
    cin >> col;
    cin >> row;
    board[row].retrieve(col,temp);
    if(temp == 'S'){
        userView[row].replace(HIT,col);
        targetsOpen --;
        totalBombs --;
        cout << "HIT! You have " << totalBombs << " bombs left." << endl;
    }else{
        userView[row].replace(MISS,col);
        totalBombs --;
        cout << "MISS! You have " << totalBombs << " bombs left." << endl;
    }
}
//Displays the cheater board, where the ships are placed
void gameClass:: dispBoardCheat() {
    char temp;
    cout << "Cheat Board" << endl;
    cout << endl;
    cout << "    0123456789 " << endl;
    cout << "   ------------" << endl;
    
    for(int x = 0; x < SIZE; x = x + 1){     
        cout << setw(2) << x << "|";
        for(int i = 0; i < SIZE; i++){ 
        board[i].retrieve(x,temp);
        cout << temp;
        }
        cout << "|";
        cout << endl;
    }


}
//Displays the userView of the board
void gameClass:: dispBoard() {
    char temp;
    cout << "User Board" << endl;
    cout << endl;
    cout << "    0123456789" << endl;
    cout << "   ------------" << endl;
    for(int x = 0; x < SIZE; x = x + 1){
        cout << setw(2) << x << " |";
        for(int i = 0; i < SIZE; i ++){
        userView[i].retrieve(x,temp);
        cout << temp;
        }
        cout << "|";
        cout << endl;
    
    }


}



//Prints the rules to the game
void gameClass:: rules() {
    cout << "340 Battleship is a guessing game for one person." << endl;
    cout << "The board is created by a 10 by 10 grid. The" << endl;
    cout << "locations of the fleets are concealed from the" << endl;
    cout << "player. The columns of the grid are numbered" << endl;
    cout << "and the rows are numbers. The user must enter" << endl;
    cout << "the desired target as a coordinate pair separated" << endl;
    cout << "by a space or a newline." << endl;
    cout << endl;
}

#endif
